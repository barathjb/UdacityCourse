Purpose of this project:
This build pipeline is aimed at automatically creating container images from a Dockerfile stored in a GIT repo awhenever a pull request is merged. The container image is a package of an analytics application for a coworking space written in Python that requires Postgres DB as a data store. 

Tools & Technologies used:
	-	AWS Codebuild
	-	AWS Elastic Container Registry
	-	Docker
	-	Elastic Kubernetes Service
	-	Helm Charts

Follow the procedure to build and deploy this application in Kubernetes
1. Create an EKS cluster in AWS.
2. Install Postgres DB using Helm Charts via Kubectl
3. Create an AWS Codebuild project with a GITHub webhook to trigger builds whenever a change is made to the public GIT repo.
4. Create an AWS ECR repository to store the container images built by Codebuild.
5. Use kubectl to deploy analytics-deployment.yaml, analytics-services.yaml, db-configmap.yaml, db-secrets.yaml

To re-run new builds:
1. Create a pull request, make changes and commit to the code repo in GitHub which will automatically trigger the codebuild pipeline and delivers a new container image.
2. Delete existing deployments and services in the EKS cluster.
3. Use kubectl to deploy analytics-deployment.yaml, analytics-services.yaml, db-configmap.yaml, db-secrets.yaml 

