# CD12352 - Infrastructure as Code Project Solution
# [Barath JB]

## Spin up/Tear Down instructions
Run the stack-manager.sh script and follow the self explanatory prompts to Deploy/Delete/Preview stacks

## Note to reviewer
LB Url: http://udagra-loadb-piqjph4xohf5-657349093.us-east-1.elb.amazonaws.com

S3 object URL: https://udagram-app-bucket.s3.amazonaws.com/Udagram-diagram-image.jpg

