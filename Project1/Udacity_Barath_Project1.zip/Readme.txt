Website Endpoint
http://my-244548615012-s3-bucket.s3-website-us-east-1.amazonaws.com/


S3 Object URL
https://my-244548615012-s3-bucket.s3.amazonaws.com/index.html


CloudFront endpoint URL
https://d3t24jtnqs36ss.cloudfront.net/